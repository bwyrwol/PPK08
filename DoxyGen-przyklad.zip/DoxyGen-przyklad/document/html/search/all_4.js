var searchData=
[
  ['opis_20projektu_0',['Opis projektu',['../opis_projektu.html',1,'']]]
];
