var indexSectionsWithContent =
{
  0: "fimnopsw",
  1: "ms",
  2: "is",
  3: "p",
  4: "fs",
  5: "mnopw"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Pliki",
  2: "Funkcje",
  3: "Zmienne",
  4: "Definicje",
  5: "Strony"
};

