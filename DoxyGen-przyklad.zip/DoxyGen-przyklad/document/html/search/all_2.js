var searchData=
[
  ['main_2ec_0',['main.c',['../main_8c.html',1,'']]],
  ['można_20wprowadzić_20podział_20na_20podrozdziały_1',['Można wprowadzić podział na podrozdziały',['../opis_projektu.html#sec1',1,'']]]
];
