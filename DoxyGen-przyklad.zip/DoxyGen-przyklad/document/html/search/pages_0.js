var searchData=
[
  ['można_20wprowadzić_20podział_20na_20podrozdziały_0',['Można wprowadzić podział na podrozdziały',['../opis_projektu.html#sec1',1,'']]]
];
