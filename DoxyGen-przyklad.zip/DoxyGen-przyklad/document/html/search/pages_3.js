var searchData=
[
  ['podrozdziały_0',['Można wprowadzić podział na podrozdziały',['../opis_projektu.html#sec1',1,'']]],
  ['podział_20na_20podrozdziały_1',['Można wprowadzić podział na podrozdziały',['../opis_projektu.html#sec1',1,'']]],
  ['projektu_2',['Opis projektu',['../opis_projektu.html',1,'']]]
];
