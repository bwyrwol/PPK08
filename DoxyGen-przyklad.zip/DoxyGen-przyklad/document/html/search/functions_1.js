var searchData=
[
  ['systimer_5fcallback_0',['systimer_callback',['../main_8c.html#aa65a9752fa834bd4e970a0751afc546b',1,'systimer_callback(void):&#160;main.c'],['../systimer_8h.html#a9964c00826959584d40ed079a871045f',1,'systimer_callback(void) __attribute__((weak)):&#160;main.c']]],
  ['systimer_5finit_1',['systimer_init',['../systimer_8c.html#ae3404ce9abc1306c155ab95ccffe8480',1,'systimer_init(uint16_t systick):&#160;systimer.c'],['../systimer_8h.html#ae3404ce9abc1306c155ab95ccffe8480',1,'systimer_init(uint16_t systick):&#160;systimer.c']]]
];
