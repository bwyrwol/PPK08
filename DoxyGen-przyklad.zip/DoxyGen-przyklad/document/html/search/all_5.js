var searchData=
[
  ['podrozdziały_0',['Można wprowadzić podział na podrozdziały',['../opis_projektu.html#sec1',1,'']]],
  ['podział_20na_20podrozdziały_1',['Można wprowadzić podział na podrozdziały',['../opis_projektu.html#sec1',1,'']]],
  ['progmem_2',['PROGMEM',['../systimer_8c.html#a9c5bf500e7587316dfee0f4f05553b3f',1,'systimer.c']]],
  ['projektu_3',['Opis projektu',['../opis_projektu.html',1,'']]]
];
